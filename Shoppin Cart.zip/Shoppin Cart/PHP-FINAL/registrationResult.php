<?php

	$title = "SHOPPING CART: REGISTRATION RESULT";
	$content = "content/registrationResultContent.php";
	
	require("template.php");	

?>