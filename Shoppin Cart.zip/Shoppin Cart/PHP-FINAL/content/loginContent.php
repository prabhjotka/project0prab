<table id = "tblLogin">
	<tr>
		<td colspan="2" style="text-align:center; font-size: 16px;">
			<?=$loginTitle?>
		</td>
		
		</tr>				
									
		<tr>
			<td>
				<?=$usernameLBL?>
			</td>
							
			<td>
				<input type="text" name="txtUser" />
			</td>
		</tr>
						
		<tr>
			<td>
				<?=$passwordLBL?>
			</td>
							
			<td>
				<input type="password" name="txtPass" />
			</td>
		</tr>
						
		<tr>
			<td colspan="2" style="text-align:center">
				<input type="submit" value="LOG-IN" name="btnLogin" id="btn" />
			</td>
		</tr>
						
</table>
