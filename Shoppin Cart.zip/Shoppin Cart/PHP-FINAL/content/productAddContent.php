<table id="tblNewCart">
	<tr>
		<td>
			<b>ADD NEW PRODUCT </b>
			<br>
			<br>		</td>							
	</tr>
	
	<tr>
		<td style="text-align: left;">	
			<b>PRODUCT IMAGE: </b>
			<input type="file" name="image" style="margin-left:20px; width: 275px;" />
		</td>		
	</tr>
	
	<tr>
		<td style="text-align: left">
			<b>PRODUCT NAME: </b>	
			<input type="text" name="txtProdDesc" maxlength="100" style="margin-left:25px;" />
			</td>
	</tr>
		
	<tr>
		<td style="text-align: left">
			<b>QUANTITY: </b>	 	    
			<input type="text" name="txtQuantity" maxlength="7" style="margin-left:73px;" />
	    </td>
	</tr>
	
	<tr>
		<td style="text-align: left">
			<b>PRICE:</b>	
			<input type="text" name="txtPrice" maxlength="18" style="margin-left:107px;" />
		</td>
	</tr>
			
	<tr>
		<td>
			<br>
			<input type="submit" name="save" value="SAVE" id="btn" />
			<input type="submit" name="cancel" value="CANCEL" id="btn" />
		</td>
	</tr>
</table>
