<div id = "bodycontent" style="text-align: left;">
						
						<div id = "aboutdiv1">
			
						<p id = "pab"> ABOUT </p>
	
						</div>
							<img src = "image/myLogo.gif" id = "aboutlogo">

					   


						<div id = "aboutdiv2">
				
						<br>
						<br>

						<p id = "pab2">
							<b> NOTE: </b> The name store/company is not an active organization in the market. It was just made for project purposes only.

						<br>
						<br>
							<b>Policies and Procedures</b>
							<ul>
							<li> The company policies just follow the basic standards and policies and procedures of a company.
							<li> The company valued all the customers.
							<li> The company rules and regulations must be strictly followed.
							<li> The company strictly implemented the terms of agreement between the customers.
							
							</ul>

						</p>

						<p id = "pab3">
							<br>
							<b>Contact Information </b>
							<br>
							If you have any comments about this sample web page.
							<br>
							Just email me: smashiton@yahoo.com
							<br>
							For any comments regarding the content of this page, thank you in advance.
						
						</p>

						

						</div>


																							
					</div>
			