<div id = "bodycontent" style="text-align: left; background-color: white;">

					<h2 id = "Vh2"> MISSION </h2>

					<p id = "Vp1">
						The main mission of the company/store is to provide the satisfaction of the customer. To get along and understand customers concerns. To have a profitable firm on which all the products in the store is badly needed by the travellers or expeditionist.

					<br>
					<br>
			
						Certain surveys must always be conducted due to the people that loves expeditions and travels. This is to provide the common issue, lates trends, unknown ideas, coming from the expert, to the persons that visit the company/store and purchase some equipment/tools and travelling guide.

					<br>
					<br>
					<b>
						Here are some mission of the company/strictly need to be done.
					</b>

					<ul>
					<li> To provide an excellent quality of service to clients.
					<li> Make customers that they are been prioritize whenever they are in the store.
					<li> To build a good relationship with the valued customers.
					<li> To have a profitable company/store which is at the same provides great satisfaction on the clients needs on the store.
				
					<li> To have a well motivated employee that is properly addressing the concerns of the customers
					
					</ul>							


					</p>

						<img src = "image/mission.gif" id = "missionlogo">


						
									

						
						
					</div>