<div id="bodycontent" style="text-align: left; background-color: white;">

						<br>
						<img src = "image/traveler.jpg" width = "200px" height = "200px" id = "travel">
			
						<i>

						<p id = "p1">
							There was a man living in a place on which there is no person except him. It is his 15th year already living in the crazy place. He is living with few animals that is living also there such as chicken, pig, and his lovely dog. 
						<br>
						<br>
							It was 15th years ago when he is lost on the place because he need to look for gasoline station to refuel its car which he left on the road. He walked for about 4 hours to look to for a gasoline station but he found nothing. When he decided to go back on his car, he noticed that the sky
						
						</p>

						<p id = "p2">
							 already get dim and suddenly strong rain came. He run on an opposite direction going back to his car and after a few minutes of running he found a small shed. He stay on the small shed while waiting that the rain will stop.
							It was already 9:00 in the evening when the rain stop. The sky is so dark already. He also didn't see any lights around excepts for the light that is coming from the half moon. He also notice after a long hours there is no vehicle that passed by. The man is already lost, totally lost.
						 
						<br>
							Until now the man still regret while reminiscing all what happened for the last 15th years while sitting infront of the shed which he is his house already. The man always blame himself why is he didn't think about the consequences about the travel he do.
						
						</p>

						</i>

						<p id = "p3">
							The above story really happens most of the time if a person that is travelling into a place which is not prepared. It must be lesson to all of us travellers to think about all the consequences that might happen not only in travelling but in everyday of our life.	In all aspects of reasoning,
it is the man to blame. Before he travel he doesn't search about the place where he go. He doesn't have maps on his side. He doesn't have a reserve a gasoline on his compartment. He doesn't prepare a large volume of food. And lastly, he doesn't prepare a safety toolkit on travelling. 
			
						</p>
						
						<p id = "p4">

							Informe me! This is a store on which you can buy all necessary travelling guide such as books, maps, etc. Several materials is also available that requires in travelling. Travelling guide books is not just the only available books in the store but also certain reference books can be seen in here. Go on and hurry to visit our store!!!
														
						</p>	

						<h2 id = "h21"align = "center"> Visit us Now!!! </h2>

									

						
						
					</div>