<div id = "bodycontent" style="text-align: left; background-color: white;">
						


						<h2 id = "Vh2"> OUR VISION </h2>

						<p id = "vp1">
							The "Inform Me!" company/store would like to ensure the satisfaction of customer who availed products in here. Satisfaction in such a way customer are well informed, questions will be answered properly and concise, and foremost products in here must be necessary to customer's eye.

						<br>
						<br>
							Company/Store like this is well planned and predicted why this is important in community. Most of rumors has been answered by the following vision of the company/store statement. Rumors such as the importance, the purposes, the contributions in the community and the good effect in human aspects.

						<br>
						<br>
						<b>

							Here are the following vision statements:
						</b>
					
						</p>
					

						<ul id = "vul">

						<li> People who loves to travel is well knowledgeable in preparing for it. Such as what to do in encountering unexpected consequences.
				
						<li> People who loves travel especially if still beginner will find a very well informative ideas that will guide in safety expedition.

						<li> Provides the newest and most efficient tool and gadgets in travelling especially in the future.
		
						<li> Documents, reports, books that is provided will make customer decide to finalize the decision about the expedition.

						<li> And last but not the least, people who really loves expedition or travel will know the do's and prevent the dont's. 
						


						</ul>


						<img src = "image/vision.gif" id = "visionlogo">
									

						
						
					</div>