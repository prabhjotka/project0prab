<?php

	$title = "SHOPPING CART: PRODUCT";
	$content = "content/listOfProductContent.php";	
	session_start();	
	require("template.php");

?>