
/*	
	$attributes = "width = 4100px;";
	
	require_once "HTML/Table.php";
	
	$tableResult = new HTML_Table($attributes);
		
	
	/*
	$table->setHeaderContents(0,0, "USERNAME");
	$table->setHeaderContents(0,1, "LAST NAME");
	$table->setHeaderContents(0,2, "FIRST NAME");
	$table->setHeaderContents(0,3, "ADDRESS");
	$table->setHeaderContents(0,4, "COUNTRY");
	$table->setHeaderContents(0,5, "PHONE NUMBER");
	$table->setHeaderContents(0,6, "MOBILE NUMBER");
	$table->setHeaderContents(0,7, "EMAIL-ADDRESS");	
	
	
	
	$rownum = 1;
	
	$tableResult->setCellContents($rownum, 0, "USERNAME: ");
	$tableResult->setCellContents($rownum+1, 0, "LAST NAME: ");
	$tableResult->setCellContents($rownum+2, 0, "FIRST NAME: ");
	$tableResult->setCellContents($rownum+3, 0, "ADDRESS: ");
	$tableResult->setCellContents($rownum+4, 0, "COUNTRY: ");
	$tableResult->setCellContents($rownum+5, 0, "MOBILE NUMBER: ");
	$tableResult->setCellContents($rownum+6, 0, "PHONE NUMBER: ");
	$tableResult->setCellContents($rownum+7, 0, "EMAIL-ADDRESS: ");
	
	while($rows=$result->fetch_row())
	{
		$tableResult->setCellContents($rownum, 1, $rows[0]);
		$tableResult->setCellContents($rownum+1, 1, $rows[1]);
		$tableResult->setCellContents($rownum+2, 1, $rows[2]);
		$tableResult->setCellContents($rownum+3, 1, $rows[3]);
		$tableResult->setCellContents($rownum+4, 1, $rows[4]);
		$tableResult->setCellContents($rownum+5, 1, $rows[5]);
		$tableResult->setCellContents($rownum+6, 1, $rows[6]);
		$tableResult->setCellContents($rownum+7, 1, $rows[7]);

	}
	
	echo $tableResult->toHTML();
	***/
?>

</table>