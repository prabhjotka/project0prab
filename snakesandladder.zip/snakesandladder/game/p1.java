package game;

import java.awt.*;
import java.awt.event.*;
import java.net.URL;

import javax.swing.*;
class p11 extends Frame implements ActionListener
{
	Button b1,b2;
	Label l1;
	p11()
	{
		super();
		b1=new Button("Start");
		b2=new Button("Exit");
		Font f=new Font("SansSerif",Font.BOLD,20);
		
		l1 = new Label("Welcome to the game");
		setLayout(null);
		setBackground(Color.PINK);
		l1.setFont(f);l1.setBackground(Color.PINK);
		l1.setBounds(120,50,210,30);
		add(l1);
		b1.setBounds(100,150,80,30);
		add(b1);
		b2.setBounds(270,150,80,30);
		add(b2);
		b1.addActionListener(this);
		b2.addActionListener(this);
		setSize(460,600);
		setVisible(true);
		
	}
	
	

	
	public void actionPerformed(ActionEvent a)
	{
	String str=a.getActionCommand();
	if(str=="Start")
	{
		p22 obj=new p22();
	}
	if(str=="Exit")
	{
		System.exit(0);
	}
	}
}
	public class p1
	{
	public static void main(String[] args) 
	{
		p11 obbj=new p11();
	}
}
