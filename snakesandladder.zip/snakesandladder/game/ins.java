
package game;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import javax.swing.*;
class in extends Frame
{
	Image img;
    MediaTracker mt;
	in()
	{
		super();
		try
		{
			mt=new MediaTracker(this);
			img=Toolkit.getDefaultToolkit().getImage("instructions2.JPG");
			mt.addImage(img,0);
			mt.waitForAll();
		}
		catch(InterruptedException ae)
		{
			System.err.print("exception:"+ae.getMessage());	
		}
		setBackground(Color.PINK);
		setSize(780,500);
		setVisible(true);
			
	}
	public void paint(Graphics g1)
	{
		
		g1.drawImage(img,20,50,this);
	}
}



public class ins
{

	public static void main(String[] args) 
	{
		in obj=new in();
	}
}
