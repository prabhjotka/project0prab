import java.awt.*;
import java.awt.event.*;
import java.net.*;
import javax.swing.*;
public class p3 extends JPanel implements ActionListener{
Image img;
MediaTracker mt;
JButton th;
Label red,blue;
int ch;
p3()
{
	super();
	th=new JButton("Throw");
	red=new Label();
	blue=new Label();
	try
	{
		mt=new MediaTracker(this);
		img=Toolkit.getDefaultToolkit().getImage("sn2.jpg");
		mt.addImage(img,0);
		mt.waitForAll();
	}
	catch(InterruptedException ae)
	{
		System.err.print("exception:"+ae.getMessage());	
	}
	
	red.setBackground(Color.RED);
	blue.setBackground(Color.BLUE);
	setLayout(null);
	th.setBackground(Color.WHITE);
	th.setBounds(10,500,100,30);
	add(th);
	red.setBounds(300,500,30,30);
	add(red);
	blue.setBounds(340,500,30,30);
	add(blue);

	th.addActionListener(this);
	
	
}
	public void paint(Graphics g)
	{
		
		g.drawImage(img,20,20,this);
		g.setColor(Color.WHITE);
		g.fillRect(200,500,50,50);
		
		 
		
		switch(ch)
		{
		case 1:
			g.setColor(Color.RED);
			g.fillOval(220,500,10,10);
		case 2:
			g.setColor(Color.RED);
			g.fillOval(220,500,10,10);
		case 3:
			g.setColor(Color.RED);
			g.fillOval(220,500,10,10);
		case 4:
			g.setColor(Color.RED);
			g.fillOval(220,500,10,10);
		case 5:
			g.setColor(Color.RED);
			g.fillOval(220,500,10,10);
			
		case 6:
			g.setColor(Color.RED);
			g.fillOval(220,500,10,10);
		}
		
	}

	public static void main(String[] args) 
	{
		JFrame frame = new JFrame("Game");
		frame.setContentPane(new p3());
		frame.setSize(460,600);
		frame.setVisible(true);
		
	}

	
	public void actionPerformed(ActionEvent arg) 
	{
		String str2=arg.getActionCommand();
		if(str2=="Throw")
		{
			ch = (int)(1+ (Math.random()*6));	
			System.out.println(ch);
			repaint();
		}
		
	}
}
