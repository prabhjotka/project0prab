package game;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import javax.swing.*;


class pub extends Frame implements ActionListener{
Image img;
MediaTracker mt;
Button th,ne,ex;
//Label red,blue;
int ch,turn=0,count=1,count1=1,pos=55,count2=0,count3=0,pos2=55,n,po1=55,po12=55;
Button l1,l2;
Label b;
//Label b1,b2;
String strr;
pub()
{
	super();

	th=new Button("Throw");
	ne=new Button("New Game");
	ex=new Button("Exit");
	l1=new Button();
	l2=new Button();
	b=new Label("Status Board:");
	//b1=new Label("yupiee!!");
	//b2=new Label("oooops!!");
	
	try
	{
		mt=new MediaTracker(this);
		img=Toolkit.getDefaultToolkit().getImage("sssn2.jpg");
		mt.addImage(img,0);
		mt.waitForAll();
	}
	catch(InterruptedException ae)
	{
		System.err.print("exception:"+ae.getMessage());	
	}
	setBackground(Color.PINK);

	setLayout(null);
	th.setBackground(Color.WHITE);
	th.setBounds(10,500,100,30);
	add(th);
	ne.setBackground(Color.WHITE);
	ne.setBounds(10,550,100,30);
	add(ne);
	ex.setBackground(Color.WHITE);
	ex.setBounds(10,600,100,30);
	add(ex);
	l1.setBackground(Color.RED);
	l2.setBackground(Color.BLUE);
	l1.setBounds(325,550,100,30);
	l2.setBounds(325,600,100,30);
	b.setBounds(325,500,100,30);
	//b1.setBounds(200,550,100,30);

	th.addActionListener(this);
	ne.addActionListener(this);
	ex.addActionListener(this);
	add(b);
	add(l1);
	add(l2);
	
setSize(460,700);
setVisible(true);
	
}
	public void paint(Graphics g)
	{
		
		g.drawImage(img,20,50,this);
		g.setColor(Color.WHITE);
		g.fillRect(200,500,50,50);
		
		if(turn%2!=0)
		 {
		 	switch(ch)
			{
			case 1:
				g.setColor(Color.RED);
			    g.fillOval(220,518,10,10);
			break;
		
			case 2:
			g.setColor(Color.RED);
			g.fillOval(210,518,10,10);
			
			g.setColor(Color.RED);
			g.fillOval(230,518,10,10);
			break;
		
			case 3:
			g.setColor(Color.RED);
			g.fillOval(220,505,10,10);
			g.setColor(Color.RED);
			g.fillOval(220,520,10,10);
			g.setColor(Color.RED);
			g.fillOval(220,535,10,10);
			break;


			case 4:
			g.setColor(Color.RED);
			g.fillOval(210,510,10,10);
			g.setColor(Color.RED);
			g.fillOval(210,530,10,10);
			g.setColor(Color.RED);
			g.fillOval(230,510,10,10);
			g.setColor(Color.RED);
			g.fillOval(230,530,10,10);
			break;
		
			case 5:
			g.setColor(Color.RED);
			g.fillOval(205,505,10,10);
			g.setColor(Color.RED);
			g.fillOval(235,505,10,10);
			g.setColor(Color.RED);
			g.fillOval(220,520,10,10);
			g.setColor(Color.RED);
			g.fillOval(205,535,10,10);
			g.setColor(Color.RED);
			g.fillOval(235,535,10,10);
			break;
			
		
			case 6:
		    g.setColor(Color.RED);
			g.fillOval(210,505,10,10);
			g.setColor(Color.RED);
			g.fillOval(210,520,10,10);
			g.setColor(Color.RED);
			g.fillOval(210,535,10,10);
			g.setColor(Color.RED);
			g.fillOval(230,505,10,10);
			g.setColor(Color.RED);
			g.fillOval(230,520,10,10);
			g.setColor(Color.RED);
			g.fillOval(230,535,10,10);
			
			if(count==2)
			{
		    g.setColor(Color.RED);
			g.fillOval(55,410,20,20);
				count=count+1;
			}
			
			break;
		}
		 	if(count2>=1)
			 {
			 	pos+=ch*35;
			 	if(pos>55 && pos<=195)
			 	{
			 		g.setColor(Color.RED);
			 	    g.fillOval(pos,410,20,20);
			 	    n=pos/35;
				 	strr=String.valueOf(n);
			 	    l1.setLabel("RED at :"+strr);
			 	}
				else if(pos==230)
			 	{
			 		g.setColor(Color.RED);
			 	    g.fillOval(265,340,20,20);
			 	    pos=965;
			 	    n=965/35;
			 	    strr=String.valueOf(n);
			 	    l1.setLabel("RED at :"+strr);
			    }
				else if(pos>230 && pos<=300)
				{
					g.setColor(Color.RED);
			 	    g.fillOval(pos,410,20,20);
			 	    n=pos/35;
				 	strr=String.valueOf(n);
			 	    l1.setLabel("RED at :"+strr);  
				}
				else if(pos==335)
			 	{
			 		g.setColor(Color.RED);
			 	    g.fillOval(370,270,20,20);
			 	    pos=1770;
			 	    n=pos/35;
			 	    strr=String.valueOf(n);
			 	    l1.setLabel("RED at :"+strr);
			 	}
				else if(pos==370)
			 	{
			 		g.setColor(Color.RED);
			 	    g.fillOval(370,410,20,20);
			 	    n=pos/35;
				 	strr=String.valueOf(n);
			 	    l1.setLabel("RED at :"+strr);
			 	}
				
				
			 	else if(pos>370 && pos<=685)
			 	{
			 		n=pos/35;
			 		n=n-10;
			 		pos2=370-((n-1)*35);
			 		g.setColor(Color.RED);
		 	    	g.fillOval(pos2,375,20,20);
		 	    	n=pos/35;
		 	    	strr=String.valueOf(n);
		 	    	l1.setLabel("RED at :"+strr);
			 	}	
			 	else if(pos==720)
			 	{
			 		g.setColor(Color.RED);
			 	    g.fillOval(90,305,20,20);
			 	    pos=1385;
			 		n=pos/35;
				 	strr=String.valueOf(n);
			 	   l1.setLabel("RED at :"+strr);
			 	}
			 	
			 	
			 	else if(pos>720 && pos <=860)
			 	{
			 		n=pos/35;
			 		n=n-20;
			 		pos2=55+((n-1)*35);
			 		g.setColor(Color.RED);
			 		g.fillOval(pos2,340,20,20);
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		l1.setLabel("RED at :"+strr);
			 	}
			 	else if(pos==895)
			 	{
			 		g.setColor(Color.RED);
			 		g.fillOval(160,235,20,20);
			 		pos=1980;
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		l1.setLabel("RED at :"+strr);
			 	}
			 	else if(pos>895 && pos <=1070)
			 	{
			 		n=pos/35;
			 		n=n-20;
			 		pos2=55+((n-1)*35);
			 		g.setColor(Color.RED);
			 		g.fillOval(pos2,340,20,20);
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		l1.setLabel("RED at :"+strr);
			 	}
		 	
		 	
			 	else if(pos>1070 && pos<=1420)
			 	{
			 		n=pos/35;
			 		n=n-30;
			 		pos2=370-((n-1)*35);
			 		g.setColor(Color.RED);
			 		g.fillOval(pos2,305,20,20);
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		l1.setLabel("RED at :"+strr);
			 	}
		 	
		 	
			 	else if(pos>1420 && pos<=1490)
			 	{
			 		n=pos/35;
			 		n=n-40;
			 		pos2=55+((n-1)*35);
			 		g.setColor(Color.RED);
			 		g.fillOval(pos2,270,20,20);
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		l1.setLabel("RED at :"+strr);
			 	}
			 	else if(pos==1525)
			 	{
			 		g.setColor(Color.RED);
			 		g.fillOval(195,375,20,20);
			 		pos=545;
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		l1.setLabel("RED at :"+strr);
			 	}
			 	else if(pos>1525 && pos<=1770)
			 	{
			 		n=pos/35;
			 		n=n-40;
			 		pos2=55+((n-1)*35);
			 		g.setColor(Color.RED);
			 		g.fillOval(pos2,270,20,20);
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		l1.setLabel("RED at :"+strr);
			 	}
			
			
			 	else if(pos>1770 && pos<=1840)
			 	{
		 			n=pos/35;
		 			n=n-50;
		 			pos2=370-((n-1)*35);
		 			g.setColor(Color.RED);
		 			g.fillOval(pos2,235,20,20);
		 			n=pos/35;
		 			strr=String.valueOf(n);
		 			l1.setLabel("RED at :"+strr);
			 	}
			 	else if(pos==1875)
			 	{
			 		g.setColor(Color.RED);
			 		g.fillOval(335,165,20,20);
			 		pos=2540;
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		l1.setLabel("RED at :"+strr);
			 	}
			 	else if(pos==1910)
			 	{
			 		g.setColor(Color.RED);
			 		g.fillOval(195,130,20,20);
			 		pos=3000;
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		l1.setLabel("RED at :"+strr);
			 	}
			 	else if(pos==1945)
			 	{
			 		g.setColor(Color.RED);
			 		g.fillOval(265,305,20,20);
			 		pos=1210;
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		l1.setLabel("RED at :"+strr);
			 	}
			 	else if(pos>1945 && pos <=2120)
			 	{
			 		n=pos/35;
			 		n=n-50;
			 		pos2=370-((n-1)*35);
			 		g.setColor(Color.RED);
			 		g.fillOval(pos2,235,20,20);
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		l1.setLabel("RED at :"+strr);
			 	}
			
			
			 	else if(pos==2155)
			 	{
			 		g.setColor(Color.RED);
			 		g.fillOval(90,130,20,20);
			 		pos=2890;
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		l1.setLabel("RED at :"+strr);
			 	}
			 	else if(pos>2155 && pos<=2435)
			 	{
			 		n=pos/35;
			 		n=n-60;
			 		pos2=55+((n-1)*35);
			 		g.setColor(Color.RED);
			 		g.fillOval(pos2,200,20,20);
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		l1.setLabel("RED at :"+strr);
			 	}
			 	else if(pos==2470)
			 	{
			 		g.setColor(Color.RED);
			 		g.fillOval(300,270,20,20);
			 		pos=1700;
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		l1.setLabel("RED at :"+strr);
			 	}
			
			
			
			
			
			 	else if(pos>2470 && pos <=2715)
			 	{
			 		n=pos/35;
			 		n=n-70;
			 		pos2=370-((n-1)*35);
			 		g.setColor(Color.RED);
			 		g.fillOval(pos2,165,20,20);
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		l1.setLabel("RED at :"+strr);
			 	}
			 	else if(pos==2750)
			 	{
			 		g.setColor(Color.RED);
			 		g.fillOval(90,270,20,20);
			 		pos=1490;
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		l1.setLabel("RED at :"+strr);
			 	}
			 	else if(pos>2750 && pos <=2820)
			 	{
			 		n=pos/35;
			 		n=n-70;
			 		pos2=370-((n-1)*35);
			 		g.setColor(Color.RED);
			 		g.fillOval(pos2,165,20,20);
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		l1.setLabel("RED at :"+strr);
			 	}
			
			
			 	else if(pos>2820 && pos<=3170)
			 	{
			 		n=pos/35;
			 		n=n-80;
			 		pos2=55+((n-1)*35);
			 		g.setColor(Color.RED);
			 		g.fillOval(pos2,130,20,20);
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		l1.setLabel("RED at :"+strr);
			 	}
			
			
			 	else if(pos>3170 && pos<=3310)
			 	{
			 		n=pos/35;
			 		n=n-90;
			 		pos2=370-((n-1)*35);
			 		g.setColor(Color.RED);
			 		g.fillOval(pos2,95,20,20);
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		l1.setLabel("RED at :"+strr);
			 	}
			 	else if(pos==3345)
			 	{
			 		g.setColor(Color.RED);
			 		g.fillOval(300,165,20,20);
			 		pos=2575;	
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		l1.setLabel("RED at :"+strr);
			 	}
			 	else if(pos==3380)
			 	{
			 		g.setColor(Color.RED);
			 		g.fillOval(90,130,20,20);
			 		pos=2890;
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		l1.setLabel("RED at :"+strr);
			 	}
			 	else if(pos>3380 && pos<3520)
			 	{
			 		n=pos/35;
			 		n=n-90;
			 		pos2=370-((n-1)*35);
			 		g.setColor(Color.RED);
			 		g.fillOval(pos2,95,20,20);
			 		n=pos/35;
			 		strr=String.valueOf(n);
			 		l1.setLabel("RED at :"+strr);
			 	}
			 	else if(pos>=3520)
			 	{
			 		JOptionPane.showMessageDialog(this,"RED WON");
			 		System.exit(0);
			 	}
			 }
		 	if(ch==6)
		 	turn=turn-1;
		 	if(pos==po1)
		 		{
		 		po1=55;
		 		}
		 }
		 	

		 	else if(turn%2==0)
		 	 {
		 	 	switch(ch)
		 		{
		 		case 1:
		 			
		 			g.setColor(Color.BLUE);	
		 			g.fillOval(220,518,10,10);
		 			break;
		 		case 2:
		 			g.setColor(Color.BLUE);
		 			g.fillOval(210,518,10,10);

		 			g.setColor(Color.BLUE);
		 			g.fillOval(230,518,10,10);
		 			break;
		 		case 3:
		 			g.setColor(Color.BLUE);
		 	    	g.fillOval(220,505,10,10);
		 			g.setColor(Color.BLUE);
		 			g.fillOval(220,520,10,10);
		 			g.setColor(Color.BLUE);
		 			g.fillOval(220,535,10,10);
		 			break;

		 		case 4:
		 			g.setColor(Color.BLUE);
		 			g.fillOval(210,510,10,10);
		 			g.setColor(Color.BLUE);
		 			g.fillOval(210,530,10,10);
		 			g.setColor(Color.BLUE);
		 			g.fillOval(230,510,10,10);
		 			g.setColor(Color.BLUE);
		 			g.fillOval(230,530,10,10);
		 			break;
		 		case 5:
		 			g.setColor(Color.BLUE);
		 			g.fillOval(205,505,10,10);
		 			g.setColor(Color.BLUE);
		 			g.fillOval(235,505,10,10);
		 			g.setColor(Color.BLUE);
		 			g.fillOval(220,520,10,10);
		 			g.setColor(Color.BLUE);
		 			g.fillOval(205,535,10,10);
		 			g.setColor(Color.BLUE);
		 			g.fillOval(235,535,10,10);
		 			break;
		 		case 6:	
		 			g.setColor(Color.BLUE);
		 			g.fillOval(210,505,10,10);
		 			g.setColor(Color.BLUE);
		 			g.fillOval(210,520,10,10);
		 			g.setColor(Color.BLUE);
		 			g.fillOval(210,535,10,10);
		 			g.setColor(Color.BLUE);
		 			g.fillOval(230,505,10,10);
		 			g.setColor(Color.BLUE);
		 			g.fillOval(230,520,10,10);
		 			g.setColor(Color.BLUE);
		 			g.fillOval(230,535,10,10);
		 			if(count1==2)
		 			{
		 				g.setColor(Color.BLUE);
		 				g.fillOval(55,415,20,20);
		 				count1=count1+1;
		 			}
		 			break;
		 		}
		 	 
		 	 	
		 	 	if(count3>=1)
		 	 	 {
		 		 	po1+=ch*35;
		 			
		 			if(po1>55 && po1<=195)
		 		 	{
		 		 		g.setColor(Color.BLUE);
		 		 	    g.fillOval(po1,410,20,20);
		 		 	    n=po1/35;
					 	strr=String.valueOf(n);
					 	l2.setLabel("BLUE at :"+strr);
		 		 	}
		 			else if(po1==230)
		 		 	{
		 		 		g.setColor(Color.BLUE);
		 		 	    g.fillOval(265,340,20,20);
		 		 	    po1=965;
		 		 	    n=po1/35;
					 	strr=String.valueOf(n);
					 	l2.setLabel("BLUE at :"+strr);
		 		 	}
		 			else if(po1>230 && po1<=300)
		 			{
		 				g.setColor(Color.BLUE);
		 		 	    g.fillOval(po1,410,20,20);
		 		 	    n=po1/35;
					 	strr=String.valueOf(n);
					 	l2.setLabel("BLUE at :"+strr);
		 			}
		 			else if(po1==335)
		 		 	{
		 		 		g.setColor(Color.BLUE);
		 		 	    g.fillOval(370,270,20,20);
		 		 	    po1=1770;
		 		 	    n=po1/35;
					 	strr=String.valueOf(n);
					 	l2.setLabel("BLUE at :"+strr);
		 		 	}
		 		 		
		 			else if(po1==370)
		 		 	{
		 		 		g.setColor(Color.BLUE);
		 		 	    g.fillOval(370,410,20,20);
		 		 	    n=po1/35;
					 	strr=String.valueOf(n);
					 	l2.setLabel("BLUE at :"+strr);
		 		 	}
		 		
		 			
		 		 	else if(po1>370 && po1<=685)
		 		 	{
		 		 		n=po1/35;
		 		 		n=n-10;
		 		 		po12=370-((n-1)*35);
		 		 		g.setColor(Color.BLUE);
		 		 		g.fillOval(po12,375,20,20);
		 		 		n=po1/35;
		 		 		strr=String.valueOf(n);
		 		 		l2.setLabel("BLUE at :"+strr);
		 		 	}	
		 		 	else if(po1==720)
		 		 	{
		 		 		g.setColor(Color.BLUE);
		 		 	    g.fillOval(90,305,20,20);
		 		 	    po1=1385;
		 		 	    n=po1/35;
					 	strr=String.valueOf(n);
					 	l2.setLabel("BLUE at :"+strr);
		 		 	}
		 		 	
		 		 	
		 		 	
		 		 	else if(po1>720 && po1 <=860)
		 		 	{
		 		 		n=po1/35;
		 		 		n=n-20;
		 		 		po12=55+((n-1)*35);
		 		 		g.setColor(Color.BLUE);
		 		 		g.fillOval(po12,340,20,20);
		 		 		n=po1/35;
		 		 		strr=String.valueOf(n);
		 		 		l2.setLabel("BLUE at :"+strr);
		 		 	}
		 		 	else if(po1==895)
		 		 	{
		 		 		g.setColor(Color.BLUE);
		 		 		g.fillOval(160,235,20,20);
		 		 		po1=1980;
		 		 		n=po1/35;
		 		 		strr=String.valueOf(n);
		 		 		l2.setLabel("BLUE at :"+strr);
		 		 	}
		 		 	else if(po1>895 && po1 <=1070)
		 		 	{
		 		 		n=po1/35;
		 		 		n=n-20;
		 		 		po12=55+((n-1)*35);
		 		 		g.setColor(Color.BLUE);
		 		 		g.fillOval(po12,340,20,20);
		 		 		n=po1/35;
		 		 		strr=String.valueOf(n);
		 		 		l2.setLabel("BLUE at :"+strr);
		 		 	}
		 	 	
		 	 
		 		 	else if(po1>1070 && po1<=1420)
		 		 	{
		 		 		n=po1/35;
		 		 		n=n-30;
		 		 		po12=370-((n-1)*35);
		 		 		g.setColor(Color.BLUE);
		 		 		g.fillOval(po12,305,20,20);
		 		 		n=po1/35;
		 		 		strr=String.valueOf(n);
		 		 		l2.setLabel("BLUE at :"+strr);
		 		 	}
		 	 	
		 	 	
		 		 	else if(po1>1420 && po1<=1490)
		 		 	{
		 		 		n=po1/35;
		 		 		n=n-40;
		 		 		po12=55+((n-1)*35);
		 		 		g.setColor(Color.BLUE);
		 		 		g.fillOval(po12,270,20,20);
		 		 		n=po1/35;
		 		 		strr=String.valueOf(n);
		 		 		l2.setLabel("BLUE at :"+strr);
		 		    }
		 		 	else if(po1==1525)
		 		 	{
		 		 		g.setColor(Color.BLUE);
		 		 		g.fillOval(195,375,20,20);
		 		 		po1=545;
		 		 		n=po1/35;
		 		 		strr=String.valueOf(n);
		 		 		n=po1/35;
		 		 		strr=String.valueOf(n);
		 		 		l2.setLabel("BLUE at :"+strr);
		 		 	}
		 		 	else if(po1>1525 && po1<=1770)
		 		 	{
		 		 		n=po1/35;
		 		 		n=n-40;
		 		 		po12=55+((n-1)*35);
		 		 		g.setColor(Color.BLUE);
		 		 		g.fillOval(po12,270,20,20);
		 		 		n=po1/35;
		 		 		strr=String.valueOf(n);
		 		 		l2.setLabel("BLUE at :"+strr);    
		 		 	}
		 		
		 		
		 		 	else if(po1>1770 && po1<=1840)
		 		 	{	
		 		 		n=po1/35;
		 		 		n=n-50;
		 		 		po12=370-((n-1)*35);
		 		 		g.setColor(Color.BLUE);
		 		 		g.fillOval(po12,235,20,20);
		 		 		n=po1/35;
		 		 		strr=String.valueOf(n);
		 		 		l2.setLabel("BLUE at :"+strr);
		 		 	}
		 		 	else if(po1==1875)
		 		 	{
		 		 		g.setColor(Color.BLUE);
		 		 		g.fillOval(335,165,20,20);
		 		 		po1=2540;
		 		 		n=po1/35;
		 		 		strr=String.valueOf(n);
		 		 		l2.setLabel("BLUE at :"+strr);
		 		 	}
		 		 	else if(po1==1910)
		 		 	{
		 		 		g.setColor(Color.BLUE);
		 		 		g.fillOval(195,130,20,20);
		 		 		po1=3000;
		 		 		n=po1/35;
		 		 		strr=String.valueOf(n);
		 		 		l2.setLabel("BLUE at :"+strr);
		 		 	}
		 		 	else if(po1==1945)
		 		 	{
		 		 		g.setColor(Color.BLUE);
		 		 		g.fillOval(265,305,20,20);
		 		 		po1=1210;
		 		 		n=po1/35;
		 		 		strr=String.valueOf(n);
		 		 		l2.setLabel("BLUE at :"+strr);
		 		 	}
		 		 	else if(po1>1945 && po1 <=2120)
		 		 	{
		 		 		n=po1/35;
		 		 		n=n-50;
		 		 		po12=370-((n-1)*35);
		 		 		g.setColor(Color.BLUE);
		 		 		g.fillOval(po12,235,20,20);
		 		 		n=po1/35;
		 		 		strr=String.valueOf(n);
		 		 		l2.setLabel("BLUE at :"+strr);
		 		 	}
		 		
		 		
		 		else if(po1==2155)
		 			{
		 				g.setColor(Color.BLUE);
		 				g.fillOval(90,130,20,20);
		 				po1=2890;
		 				n=po1/35;
		 				strr=String.valueOf(n);
		 				l2.setLabel("BLUE at :"+strr);
		 			}
		 		else if(po1>2155 && po1<=2435)
		 	 		{
		 				n=po1/35;
		 				n=n-60;
		 				po12=55+((n-1)*35);
		 				g.setColor(Color.BLUE);
		 				g.fillOval(po12,200,20,20);
		 				n=po1/35;
		 				strr=String.valueOf(n);
		 				l2.setLabel("BLUE at :"+strr);    
		 	 		}
		 		else if(po1==2470)
		 			{
		 				g.setColor(Color.BLUE);
		 				g.fillOval(300,270,20,20);
		 				po1=1700;
		 				n=po1/35;
		 				strr=String.valueOf(n);
		 				l2.setLabel("BLUE at :"+strr);
		 			}
		 		
		 		
		 		else if(po1>2470 && po1 <=2715)
		 	 		{
		 	 			n=po1/35;
		 	 			n=n-70;
		 	 			po12=370-((n-1)*35);
		 	 			g.setColor(Color.BLUE);
		 	 			g.fillOval(po12,165,20,20);
		 	 			n=po1/35;
		 	 			strr=String.valueOf(n);
		 	 			l2.setLabel("BLUE at :"+strr);
		 	 		}
		 		else if(po1==2750)
		 			{
		 				g.setColor(Color.BLUE);
		 				g.fillOval(90,270,20,20);
		 				po1=1490;
		 				n=po1/35;
		 				strr=String.valueOf(n);
		 				l2.setLabel("BLUE at :"+strr);
		 			}
		 		else if(po1>2750 && po1 <=2820)
		 	 		{
		 	 			n=po1/35;
		 	 			n=n-70;
		 	 			po12=370-((n-1)*35);
		 	 			g.setColor(Color.BLUE);
		 	 			g.fillOval(po12,165,20,20);
		 	 			n=po1/35;
		 	 			strr=String.valueOf(n);
		 	 			l2.setLabel("BLUE at :"+strr);
		 	 		}
		 		
		 		
		 		
		 		
		 		else if(po1>2820 && po1<=3170)
		 	 		{
		 				n=po1/35;
		 				n=n-80;
		 				po12=55+((n-1)*35);
		 				g.setColor(Color.BLUE);
		 				g.fillOval(po12,130,20,20);
		 				n=po1/35;
		 				strr=String.valueOf(n);
		 				l2.setLabel("BLUE at :"+strr);    
		 	 		}
		 		
		 		
		 		else if(po1>3170 && po1<=3310)
		 	 		{
		 				n=po1/35;
		 				n=n-90;
		 				po12=370-((n-1)*35);
		 				g.setColor(Color.BLUE);
		 				g.fillOval(po12,95,20,20);
		 				n=po1/35;
		 				strr=String.valueOf(n);
		 				l2.setLabel("BLUE at :"+strr);    
		 	 		}
		 		else if(po1==3345)
		 			{
		 				g.setColor(Color.BLUE);
		 				g.fillOval(300,165,20,20);
		 				po1=2575;
		 				n=po1/35;
		 				strr=String.valueOf(n);
		 				l2.setLabel("BLUE at :"+strr);
		 			}
		 		else if(po1==3380)
		 			{
		 				g.setColor(Color.BLUE);
		 				g.fillOval(90,130,20,20);
		 				po1=2890;	
		 				n=po1/35;
		 				strr=String.valueOf(n);
		 				l2.setLabel("BLUE at :"+strr);
		 			}
		 		else if(po1>3380 && po1<3520)
		 	 		{
		 				n=po1/35;
		 				n=n-90;
		 				po12=370-((n-1)*35);
		 				g.setColor(Color.BLUE);
		 				g.fillOval(po12,95,20,20);
		 				n=po1/35;
		 				strr=String.valueOf(n);
		 				l2.setLabel("BLUE at :"+strr);
		 	 		}
		 		else if(po1>=3520)
		 			{
		 				JOptionPane.showMessageDialog(this,"BLUE WON");
		 				System.exit(0);
		 			}
		 		 }
		 	 	if(ch==6)		 	 
		 	 		turn=turn-1;
		 	 	if(po1==pos)
		 	 	{
		 	 		pos=55;
		 	 	}
		 	 }
	}

	
	
	public void actionPerformed(ActionEvent arg) 
	{
		String str2=arg.getActionCommand();
		
		if(str2=="Throw")
		{	
			
			turn=turn+1;
			ch = (int)(1+ (Math.random()*6));
			
			if(turn%2!=0)
			{
		    if(count==1)
			{
		    	if(ch==6)
				{
					count=count+1;				
				}
			}
			else 
			{
				count2=count2+1;
			}
			}
			else if(turn%2==0)
			{
			if(count1==1)
			{
				if(ch==6)
				{
					count1=count1+1;
				}
			}
			else
			{
				count3=count3+1;
			}
			}
			
			repaint();
		}
		if(str2=="New Game")
		{
			pub ob=new pub();                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
		}
		if(str2=="Exit")
		{
			System.exit(0);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
		}
		}
}
public class p0
{
	public static void main(String[] args) 
	{                                                                           
		pub ob=new pub();
	}
}