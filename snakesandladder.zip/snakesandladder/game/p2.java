package game;


import java.awt.*;
import java.awt.event.*;
import java.net.*;
import javax.swing.*;
class p22 extends Frame implements ActionListener{
Button b3,b4,b5;
p22()
{
	super();
	b3=new Button("2 Players");
	b4=new Button("Instructions");
	b5=new Button("4 Players");
	setLayout(null);
	setBackground(Color.PINK);
	b3.setBackground(Color.PINK);
	b3.setBounds(170,110,100,30);
	add(b3);
	b4.setBackground(Color.PINK);
	b4.setBounds(170,330,100,30);
	add(b4);
	b5.setBackground(Color.PINK);
	b5.setBounds(170,220,100,30);
	add(b5);
	b3.addActionListener(this);
	b4.addActionListener(this);
	b5.addActionListener(this);
	setSize(460,600);
	setVisible(true);
}
public void actionPerformed(ActionEvent ar) {
	String str1=ar.getActionCommand();
	if(str1=="2 Players")
	{
		pub ob=new pub();
	}
	if(str1=="Instructions")
	{
		in obj=new in();
	}
	if(str1=="4 Players")
	{
		abc ob1=new abc();
	}
	
}	
}
public class p2
{
	public static void main(String[] args)
	{
		p22 objj=new p22();
		//frame.setSize(500,300);
		//frame.setVisible(true);
	}
}

	
