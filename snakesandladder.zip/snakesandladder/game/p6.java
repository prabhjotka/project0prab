
package game;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import javax.swing.*;

class abc extends Frame implements ActionListener
{
	Image img;
    MediaTracker mt;
	Button th,ne,ex;
	Color turn[]=new Color[6];
	int i=0;
	Button r,b,g,y,l1;
	int ch,pos2=55,n;
	int q[]=new int[5];
	int count[]=new int[5];
	String strr;
	int test=0;int j=0;
	//public void move(int,int);

	abc()
	{
		super();

		th=new Button("Throw");
		ne=new Button("New Game");
		ex=new Button("Exit");
		b=new Button();
		r=new Button();
		g=new Button();
		y=new Button();
		l1=new Button();
		q[1]=55;
		q[2]=55;
		q[3]=55;
		q[4]=55;
		count[1]=0;count[2]=0;count[3]=0;count[4]=0;
		turn[1]=new Color(253,43,43);
		turn[2]=new Color(100,255,100);
		turn[3]=new Color(100,100,255);
		turn[4]=new Color(247,244,5);
		try
		{
			mt=new MediaTracker(this);
			img=Toolkit.getDefaultToolkit().getImage("sssn2.jpg");
			mt.addImage(img,0);
			mt.waitForAll();
		}
		catch(InterruptedException ae)
		{
			System.err.print("exception:"+ae.getMessage());	
		}
		setBackground(Color.PINK);

		setLayout(null);
		th.setBackground(Color.WHITE);
		th.setBounds(10,500,100,30);
		add(th);
		ne.setBackground(Color.WHITE);
		ne.setBounds(10,550,100,30);
		add(ne);
		ex.setBackground(Color.WHITE);
		ex.setBounds(10,600,100,30);
		add(ex);
		th.addActionListener(this);
		ne.addActionListener(this);
		ex.addActionListener(this);
		b.addActionListener(this);
		r.addActionListener(this);
		y.addActionListener(this);
		g.addActionListener(this);
		r.setBackground(turn[1]);
		r.setBounds(325,500,30,30);
		b.setBackground(turn[3]);
		b.setBounds(325,600,30,30);
		g.setBackground(turn[2]);
		g.setBounds(325,550,30,30);
		y.setBackground(turn[4]);
		y.setBounds(325,650,30,30);
		
		add(b);
		add(g);
		add(y);
		add(r);
	    setSize(460,700);
	    setVisible(true);
		
	}
	public void paint(Graphics g1)
	{
		
		g1.drawImage(img,20,50,this);
		g1.setColor(Color.WHITE);
		g1.fillRect(200,500,50,50);
		switch(ch)
		{
		case 1:
			g1.setColor(turn[i]);
		    g1.fillOval(220,518,10,10);
		break;
	
		case 2:
		g1.setColor(turn[i]);
		g1.fillOval(210,518,10,10);
		
		g1.setColor(turn[i]);
		g1.fillOval(230,518,10,10);
		break;
	
		case 3:
		g1.setColor(turn[i]);
		g1.fillOval(220,505,10,10);
		g1.setColor(turn[i]);
		g1.fillOval(220,520,10,10);
		g1.setColor(turn[i]);
		g1.fillOval(220,535,10,10);
		break;


		case 4:
		g1.setColor(turn[i]);
		g1.fillOval(210,510,10,10);
		g1.setColor(turn[i]);
		g1.fillOval(210,530,10,10);
		g1.setColor(turn[i]);
		g1.fillOval(230,510,10,10);
		g1.setColor(turn[i]);
		g1.fillOval(230,530,10,10);
		break;
	
		case 5:
		g1.setColor(turn[i]);
		g1.fillOval(205,505,10,10);
		g1.setColor(turn[i]);
		g1.fillOval(235,505,10,10);
		g1.setColor(turn[i]);
		g1.fillOval(220,520,10,10);
		g1.setColor(turn[i]);
		g1.fillOval(205,535,10,10);
		g1.setColor(turn[i]);
		g1.fillOval(235,535,10,10);
		break;
		
	
		case 6:
	    g1.setColor(turn[i]);
		g1.fillOval(210,505,10,10);
		g1.setColor(turn[i]);
		g1.fillOval(210,520,10,10);
		g1.setColor(turn[i]);
		g1.fillOval(210,535,10,10);
		g1.setColor(turn[i]);
		g1.fillOval(230,505,10,10);
		g1.setColor(turn[i]);
		g1.fillOval(230,520,10,10);
		g1.setColor(turn[i]);
		g1.fillOval(230,535,10,10);
		test=1;
		if(count[1]==0 && ch==6 && i==1)
		{
			r.setBounds(55,410,20,20);
			count[1]=1;
			
		}
		else if(count[2]==0 && ch==6 && i==2)
		{
			g.setBounds(60,410,20,20);
			count[2]=1;
		}
		else if(count[3]==0 && ch==6 && i==3)
		{
			b.setBounds(50,410,20,20);
			count[3]=1;
		}
		else if(count[4]==0 && ch==6 && i==4)
		{
			y.setBounds(45,410,20,20);
			count[4]=1;
		}
		break;

		}
		
		
		
		
	}
	
	public void actionPerformed(ActionEvent ar)
	{
		String str=ar.getActionCommand();
		
		if(str=="Throw")
		{ch =(int)(1+ (Math.random()*6));
		j=0;
		
			if(i<4)
			{
				i=i+1;
			}
			else
			{	i=1;
			}
			
		
		repaint();
		
		}
		switch(i)
		{
		case 1:
			
			if(test==1)
			{
				
				i=i-1;
				if(i==0)
				{
					i=4;
					test=0;	
				
				}
					
			}
			if(r.hasFocus()&& count[1]==1)
			{
				i=1;
				
				move(i,r,ch);
			}
			break;
	    case 2:
	    	if(test==1)
	    	{
	    		
	    		i=i-1;
	    		if(i==0)
				{
					i=4;
					test=0;	
				
				}
	    		
	    		test=0;	
	    	}
	    	if(g.hasFocus()&& count[2]==1)
			{
				i=2;
				
			    move(i,g,ch);
			}
	    	break;
	    case 3:
	    	if(test==1)
	    	{
	    		i=i-1;
	    		if(i==0)
				{
					i=4;
					test=0;	
				
				}
	    		
	    		test=0;	
	    	}
	    	if(b.hasFocus()&& count[3]==1)
			{
				i=3;
				move(i,b,ch);
			}
	    	break;
	    case 4:
	    	if(test==1)
	    	{
	    		i=i-1;
	    		if(i==0)
				{
					i=4;
					test=0;	
				
				}
	    		
	    		test=0;	
	    	}
	    	if(y.hasFocus()&& count[4]==1)
			{
				i=4;
			move(i,y,ch);
			}
	    	break;
		}
		if(str=="New Game")
		{
			pub ob=new pub();                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           
		}
		if(str=="Exit")
		{
			System.exit(0);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
		}
		
		}
	public void move(int i,Button m,int ch)
	{
		
		q[i]+=ch*35;
		System.out.println(j);
		if(q[i]>55 && q[i]<=195)
		{
			
		    m.setBounds(q[i],410,20,20);
		    
		    System.out.println(j);
		    n=q[i]/35;
		 	
		    
		}
		else if(q[i]==230)
		{
			
		    m.setBounds(265,340,20,20);
		    q[i]=965;
		    n=965/35; 
		    
	   }
		else if(q[i]>230 && q[i]<=300)
		{
			
		    m.setBounds(q[i],410,20,20);
		    n=q[i]/35;
		   
		}
		else if(q[i]==335)
		{
			
		    m.setBounds(370,270,20,20);
		    q[i]=1770;
		    n=q[i]/35;
		    
		  
		}
		else if(q[i]==370)
		{
			
		    m.setBounds(370,410,20,20);
		    n=q[i]/35;
		 	
		}
		
		
		else if(q[i]>370 && q[i]<=685)
		{
			n=q[i]/35;
			n=n-10;
			pos2=370-((n-1)*35);
			
	    	m.setBounds(pos2,375,20,20);
	    	n=q[i]/35;
	    	
		}	
		else if(q[i]==720)
		{
			
		    m.setBounds(90,305,20,20);
		    q[i]=1385;
			n=q[i]/35;
		 	
		}
		
		
		else if(q[i]>720 && q[i] <=860)
		{
			n=q[i]/35;
			n=n-20;
			pos2=55+((n-1)*35);
			
			m.setBounds(pos2,340,20,20);
			n=q[i]/35;
			
		}
		else if(q[i]==895)
		{
			
			m.setBounds(160,235,20,20);
			q[i]=1980;
			n=q[i]/35;
			
		}
		else if(q[i]>895 && q[i] <=1070)
		{
			n=q[i]/35;
			n=n-20;
			pos2=55+((n-1)*35);
			
			m.setBounds(pos2,340,20,20);
			n=q[i]/35;
			
		}


		else if(q[i]>1070 && q[i]<=1420)
		{
			n=q[i]/35;
			n=n-30;
			pos2=370-((n-1)*35);
			
			m.setBounds(pos2,305,20,20);
			n=q[i]/35;
			
		}


		else if(q[i]>1420 && q[i]<=1490)
		{
			n=q[i]/35;
			n=n-40;
			pos2=55+((n-1)*35);
			
			m.setBounds(pos2,270,20,20);
			n=q[i]/35;
			
		}
		else if(q[i]==1525)
		{
			
			m.setBounds(195,375,20,20);
			q[i]=545;
			n=q[i]/35;
			
		}
		else if(q[i]>1525 && q[i]<=1770)
		{
			n=q[i]/35;
			n=n-40;
			pos2=55+((n-1)*35);
			
			m.setBounds(pos2,270,20,20);
			n=q[i]/35;
			
		}


		else if(q[i]>1770 && q[i]<=1840)
		{
			n=q[i]/35;
			n=n-50;
			pos2=370-((n-1)*35);
			
			m.setBounds(pos2,235,20,20);
			n=q[i]/35;
			
		}
		else if(q[i]==1875)
		{
			
			m.setBounds(335,165,20,20);
			q[i]=2540;
			n=q[i]/35;
			strr=String.valueOf(n);
			n=q[i]/35;
			
		}
		else if(q[i]==1910)
		{
			
			m.setBounds(195,130,20,20);
			q[i]=3000;
			n=q[i]/35;
			
		}
		else if(q[i]==1945)
		{
			
			m.setBounds(265,305,20,20);
			q[i]=1210;
			n=q[i]/35;
			
		}
		else if(q[i]>1945 && q[i] <=2120)
		{
			n=q[i]/35;
			n=n-50;
			pos2=370-((n-1)*35);
			
			m.setBounds(pos2,235,20,20);
			n=q[i]/35;
			
		}


		else if(q[i]==2155)
		{
			
			m.setBounds(90,130,20,20);
			q[i]=2890;
			n=q[i]/35;
			strr=String.valueOf(n);
			n=q[i]/35;
			
		}
		else if(q[i]>2155 && q[i]<=2435)
		{
			n=q[i]/35;
			n=n-60;
			pos2=55+((n-1)*35);
			
			m.setBounds(pos2,200,20,20);
			n=q[i]/35;
			
		}
		else if(q[i]==2470)
		{
			
			m.setBounds(300,270,20,20);
			q[i]=1700;
			n=q[i]/35;
			strr=String.valueOf(n);
			n=q[i]/35;
			
		}





		else if(q[i]>2470 && q[i] <=2715)
		{
			n=q[i]/35;
			n=n-70;
			pos2=370-((n-1)*35);
			
			m.setBounds(pos2,165,20,20);
			n=q[i]/35;
			
		}
		else if(q[i]==2750)
		{
			
			m.setBounds(90,270,20,20);
			q[i]=1490;
			n=q[i]/35;
			
		}
		else if(q[i]>2750 && q[i] <=2820)
		{
			n=q[i]/35;
			n=n-70;
			pos2=370-((n-1)*35);
			
			m.setBounds(pos2,165,20,20);
			n=q[i]/35;
			
		}


		else if(q[i]>2820 && q[i]<=3170)
		{
			n=q[i]/35;
			n=n-80;
			pos2=55+((n-1)*35);
			
			m.setBounds(pos2,130,20,20);
			n=q[i]/35;
			
		}


		else if(q[i]>3170 && q[i]<=3310)
		{
			n=q[i]/35;
			n=n-90;
			pos2=370-((n-1)*35);
			
			m.setBounds(pos2,95,20,20);
			n=q[i]/35;
			
		}
		else if(q[i]==3345)
		{
			
			m.setBounds(300,165,20,20);
			q[i]=2575;	
			n=q[i]/35;
			
		}
		else if(q[i]==3380)
		{
			
			m.setBounds(90,130,20,20);
			q[i]=2890;
			n=q[i]/35;
			
		}
		else if(q[i]>3380 && q[i]<3520)
		{
			n=q[i]/35;
			n=n-90;
			pos2=370-((n-1)*35);
			
			m.setBounds(pos2,95,20,20);
			n=q[i]/35;
			
		}
		else if(q[i]>=3520)
		{
			JOptionPane.showMessageDialog(this,"YOU WON");
			System.exit(0);
		}

		
	
}}

public class p6 
{

	public static void main(String[] args)
	{
		abc ob1=new abc();
	}
}
